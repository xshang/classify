# Title: Image Segmentation Data Set
# Source: UCI Machine Learning Repository

download.file("http://archive.ics.uci.edu/ml/machine-learning-databases/image/segmentation.data", "segmentation.data")
download.file("http://archive.ics.uci.edu/ml/machine-learning-databases/image/segmentation.test",
"segmentation.test")
download.file("http://archive.ics.uci.edu/ml/machine-learning-databases/image/segmentation.names",
"segmentation.names")
