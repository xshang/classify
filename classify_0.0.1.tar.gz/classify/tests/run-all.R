library('testthat')
library('classify')

test_package('classify')
